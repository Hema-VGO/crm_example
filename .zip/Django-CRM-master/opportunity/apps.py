from django.apps import AppConfig


class OpportunityConfig(AppConfig):
    name = "opportunity"
