from django.apps import AppConfig


class TeamsConfig(AppConfig):
    name = "teams"
